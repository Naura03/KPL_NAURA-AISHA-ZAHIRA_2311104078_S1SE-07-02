﻿class Program
{
    static void Main(string[] args)
    {
        KuliahMahasiswa2311104078.ReadJSON();
    }
}
