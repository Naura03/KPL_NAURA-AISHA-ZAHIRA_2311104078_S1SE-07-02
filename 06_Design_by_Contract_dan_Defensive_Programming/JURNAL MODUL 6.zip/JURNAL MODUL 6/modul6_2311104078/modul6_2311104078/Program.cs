﻿using modul6_2311104078;

class Program
{
    static void Main(string[] args)
    {
        SayaTubeUser user = new SayaTubeUser("Naura");

        try
        {
            for (int i = 1; i <= 10; i++)
            {
                SayaTubeVideo video = new SayaTubeVideo($"Review Film {i} oleh Naura");
                video.IncreasePlayCount(1000000);
                user.AddVideo(video);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }

        user.PrintAllVideoPlaycount();
        Console.WriteLine("Total Play Count: " + user.GetTotalVideoPlayCount());
    }
}
