﻿using System;
using AljabarLibraries;

namespace AljabarConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] akar = Aljabar.AkarPersamaanKuadrat(new double[] { 1, -3, -10 });
            Console.WriteLine("Akar-akar persamaan kuadrat x² - 3x - 10:");
            foreach (double a in akar)
                Console.WriteLine(a);

            double[] hasilKuadrat = Aljabar.HasilKuadrat(new double[] { 2, -3 });
            Console.WriteLine("\nHasil kuadrat dari persamaan 2x - 3:");
            Console.WriteLine($"{hasilKuadrat[0]}x² + {hasilKuadrat[1]}x + {hasilKuadrat[2]}");
        }
    }
}
