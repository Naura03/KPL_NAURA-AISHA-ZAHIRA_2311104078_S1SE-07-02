﻿using System;

namespace MatematikaLibraries
{
    public class Matematika
    {
        public static int FPB(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }

        public static int KPK(int a, int b)
        {
            return (a * b) / FPB(a, b);
        }

        public static string Turunan(int[] koefisien)
        {
            string result = "";
            int pangkat = koefisien.Length - 1;

            for (int i = 0; i < koefisien.Length - 1; i++)
            {
                int coef = koefisien[i] * (pangkat - i);
                int exp = pangkat - i - 1;

                if (coef == 0) continue;

                string term = coef > 0 && result != "" ? $" + {coef}" : coef < 0 ? $" - {Math.Abs(coef)}" : $"{coef}";

                if (exp > 1)
                    term += $"x{exp}";
                else if (exp == 1)
                    term += "x";

                result += term;
            }

            return result.Trim();
        }

        public static string Integral(int[] koefisien)
        {
            string result = "";
            int pangkat = koefisien.Length - 1;

            for (int i = 0; i < koefisien.Length; i++)
            {
                int exp = pangkat - i + 1;
                double coef = (double)koefisien[i] / exp;

                string term = coef > 0 && result != "" ? $" + {coef}" : coef < 0 ? $" - {Math.Abs(coef)}" : $"{coef}";

                if (exp > 1)
                    term += $"x{exp}";
                else if (exp == 1)
                    term += "x";

                result += term;
            }

            return result + " + C";
        }
    }
}
