﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using tpmodul12_2311104078;

namespace tpmodul12_2311104078_Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_Positive()
        {
            Assert.AreEqual("Positif", TandaBilangan.CariTandaBilangan(5));
        }

        [TestMethod]
        public void Test_Negative()
        {
            Assert.AreEqual("Negatif", TandaBilangan.CariTandaBilangan(-5));
        }

        [TestMethod]
        public void Test_Zero()
        {
            Assert.AreEqual("Nol", TandaBilangan.CariTandaBilangan(0));
        }
    }
}
