﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace tpmodul12_2311104078.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestCariTandaBilangan()
        {
            Assert.AreEqual("Negatif", CariTandaBilangan(-5));
            Assert.AreEqual("Positif", CariTandaBilangan(5));
            Assert.AreEqual("Nol", CariTandaBilangan(0));
        }
    }
}
