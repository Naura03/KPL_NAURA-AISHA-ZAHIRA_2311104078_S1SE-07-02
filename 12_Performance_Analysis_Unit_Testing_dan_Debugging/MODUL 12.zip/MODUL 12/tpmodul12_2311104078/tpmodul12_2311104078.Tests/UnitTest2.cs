﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace tpmodul12_2311104078.Tests
{
	[TestClass]
	public class UnitTest2
	{
		[TestMethod]
		public void TestMethod1()
		{
		}
	}
}
