﻿using System;
using System.Windows.Forms;

namespace modul12_2311104078
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnHitung_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(textBox1.Text);
                int b = int.Parse(textBox2.Text);

                int hasil = Perhitungan.CariNilaiPangkat(a, b);
                labelHasil.Text = "Hasil: " + hasil.ToString();
            }
            catch (FormatException)
            {
                labelHasil.Text = "Input harus berupa angka.";
            }
        }
    }
}
