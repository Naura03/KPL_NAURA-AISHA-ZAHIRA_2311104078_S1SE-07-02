﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using modul12_2311104078;

namespace modul12_2311104078_Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestBEqualsZero()
        {
            Assert.AreEqual(1, Perhitungan.CariNilaiPangkat(0, 0));
        }

        [TestMethod]
        public void TestBNegative()
        {
            Assert.AreEqual(-1, Perhitungan.CariNilaiPangkat(2, -3));
        }

        [TestMethod]
        public void TestBGreaterThan10()
        {
            Assert.AreEqual(-2, Perhitungan.CariNilaiPangkat(2, 11));
        }

        [TestMethod]
        public void TestAGreaterThan100()
        {
            Assert.AreEqual(-2, Perhitungan.CariNilaiPangkat(101, 2));
        }

        [TestMethod]
        public void TestOverflow()
        {
            Assert.AreEqual(-3, Perhitungan.CariNilaiPangkat(100, 10));
        }

        [TestMethod]
        public void TestNormalCase()
        {
            Assert.AreEqual(32, Perhitungan.CariNilaiPangkat(2, 5));
        }

        [TestMethod]
        public void TestBaseCase()
        {
            Assert.AreEqual(1, Perhitungan.CariNilaiPangkat(1, 1));
        }
    }
}
