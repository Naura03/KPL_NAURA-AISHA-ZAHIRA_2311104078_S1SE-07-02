﻿using System;

class Program
{
    static void Main()
    {
        InputNama();
        CetakArray();
        CekBilanganPrima();
    }

    static void InputNama()
    {
        Console.Write("Masukkan nama Anda: ");
        string nama = Console.ReadLine();
        Console.WriteLine($"Selamat datang, {nama}!");
    }

    static void CetakArray()
    {
        int[] angka = new int[50];

        for (int i = 0; i < angka.Length; i++)
        {
            angka[i] = i;
            Console.Write($"{i} ");

            if (i % 6 == 0)
                Console.Write("#$#$");
            else if (i % 2 == 0)
                Console.Write("##");
            else if (i % 3 == 0)
                Console.Write("$$");

            Console.WriteLine();
        }
    }

    static void CekBilanganPrima()
    {
        Console.Write("Masukkan sebuah angka (1-10000): ");
        int angkaInput = Convert.ToInt32(Console.ReadLine());

        bool isPrima = true;

        if (angkaInput <= 1)
        {
            isPrima = false;
        }
        else
        {
            for (int i = 2; i * i <= angkaInput; i++)
            {
                if (angkaInput % i == 0)
                {
                    isPrima = false;
                    break;
                }
            }
        }

        if (isPrima)
            Console.WriteLine($"Angka {angkaInput} merupakan bilangan prima.");
        else
            Console.WriteLine($"Angka {angkaInput} bukan merupakan bilangan prima.");
    }
}
