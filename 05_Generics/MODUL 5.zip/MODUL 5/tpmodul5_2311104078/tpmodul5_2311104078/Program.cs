<<<<<<< HEAD
﻿using tpmodul5_2311104078;

class Program
{
    static void Main(string[] args)
    {
        HaloGeneric halo = new HaloGeneric();
        halo.SapaUser("Naura");
=======
﻿class Program
{
    static void Main(string[] args)
    {
        DataGeneric<string> dataNim = new DataGeneric<string>("2311104078");
        dataNim.PrintData();
>>>>>>> generic-class
    }
}
