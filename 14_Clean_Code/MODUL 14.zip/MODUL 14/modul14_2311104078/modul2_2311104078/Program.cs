﻿using System;

class Program
{
    static void Main()
    {
        InputNama();
        CetakAngkaDenganSimbol();
        CekBilanganPrima();

        Console.WriteLine("\nTekan Enter untuk keluar...");
        Console.ReadLine();
    }

    /// <summary>
    /// Menerima input nama dari pengguna dan menampilkannya.
    /// </summary>
    static void InputNama()
    {
        Console.Write("Masukkan nama Anda: ");
        string namaPengguna = Console.ReadLine();
        Console.WriteLine($"Selamat datang, {namaPengguna}!");
    }

    /// <summary>
    /// Mencetak angka 0–49 dengan simbol sesuai kondisi kelipatan.
    /// </summary>
    static void CetakAngkaDenganSimbol()
    {
        int[] deretAngka = new int[50];

        for (int i = 0; i < deretAngka.Length; i++)
        {
            deretAngka[i] = i;
            Console.Write($"{i} ");

            if (i % 6 == 0)
                Console.Write("#$#$");
            else if (i % 2 == 0)
                Console.Write("##");
            else if (i % 3 == 0)
                Console.Write("$$");

            Console.WriteLine();
        }
    }

    /// <summary>
    /// Mengecek apakah input angka dari user adalah bilangan prima.
    /// </summary>
    static void CekBilanganPrima()
    {
        Console.Write("Masukkan sebuah angka (1-10000): ");
        int angkaInput = Convert.ToInt32(Console.ReadLine());

        bool isPrima = true;

        if (angkaInput <= 1)
        {
            isPrima = false;
        }
        else
        {
            for (int i = 2; i * i <= angkaInput; i++)
            {
                if (angkaInput % i == 0)
                {
                    isPrima = false;
                    break;
                }
            }
        }

        if (isPrima)
            Console.WriteLine($"Angka {angkaInput} merupakan bilangan prima.");
        else
            Console.WriteLine($"Angka {angkaInput} bukan merupakan bilangan prima.");
    }
}
