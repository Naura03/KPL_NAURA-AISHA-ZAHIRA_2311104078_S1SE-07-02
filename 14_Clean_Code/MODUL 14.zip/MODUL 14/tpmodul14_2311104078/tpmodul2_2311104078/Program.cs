﻿using System;

class Program
{
    static void Main()
    {
        // Meminta input huruf dari pengguna
        Console.Write("Masukkan satu huruf: ");
        char inputHuruf = Char.ToUpper(Console.ReadKey().KeyChar);
        Console.WriteLine();

        // Mengecek apakah huruf tersebut vokal
        if (IsHurufVokal(inputHuruf))
        {
            Console.WriteLine($"Huruf {inputHuruf} merupakan huruf vokal");
        }
        else
        {
            Console.WriteLine($"Huruf {inputHuruf} merupakan huruf konsonan");
        }

        // Menampilkan angka genap
        int[] angkaGenap = { 2, 4, 6, 8, 10 };
        TampilkanAngkaGenap(angkaGenap);
    }

    /// <summary>
    /// Mengecek apakah huruf termasuk vokal
    /// </summary>
    static bool IsHurufVokal(char huruf)
    {
        return huruf == 'A' || huruf == 'I' || huruf == 'U' || huruf == 'E' || huruf == 'O';
    }

    /// <summary>
    /// Menampilkan isi array angka genap ke konsol
    /// </summary>
    static void TampilkanAngkaGenap(int[] angka)
    {
        for (int i = 0; i < angka.Length; i++)
        {
            Console.WriteLine($"Angka genap ke-{i + 1} : {angka[i]}");
        }
    }
}
