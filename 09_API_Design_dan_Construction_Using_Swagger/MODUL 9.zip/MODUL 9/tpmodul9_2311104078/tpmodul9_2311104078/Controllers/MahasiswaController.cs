﻿using Microsoft.AspNetCore.Mvc;
using tpmodul9_2311104078.Models;

namespace tpmodul9_2311104078.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MahasiswaController : ControllerBase
    {
        // Static list menyimpan data mahasiswa
        static List<Mahasiswa> daftarMahasiswa = new List<Mahasiswa>
        {
            new Mahasiswa { Nama = "Naura Aisha Zahira", Nim = "2311104078" },
            new Mahasiswa { Nama = "Anggota 2", Nim = "2311104XXX" },
            new Mahasiswa { Nama = "Anggota 3", Nim = "2311104XXX" },
        };

        // GET /api/mahasiswa
        [HttpGet]
        public ActionResult<List<Mahasiswa>> GetAll()
        {
            return daftarMahasiswa;
        }

        // GET /api/mahasiswa/{index}
        [HttpGet("{index}")]
        public ActionResult<Mahasiswa> GetByIndex(int index)
        {
            if (index < 0 || index >= daftarMahasiswa.Count)
                return NotFound("Index tidak ditemukan.");
            return daftarMahasiswa[index];
        }

        // POST /api/mahasiswa
        [HttpPost]
        public ActionResult Post([FromBody] Mahasiswa mhs)
        {
            daftarMahasiswa.Add(mhs);
            return Ok("Mahasiswa berhasil ditambahkan.");
        }

        // DELETE /api/mahasiswa/{index}
        [HttpDelete("{index}")]
        public ActionResult Delete(int index)
        {
            if (index < 0 || index >= daftarMahasiswa.Count)
                return NotFound("Index tidak valid.");
            daftarMahasiswa.RemoveAt(index);
            return Ok("Mahasiswa berhasil dihapus.");
        }
    }
}
