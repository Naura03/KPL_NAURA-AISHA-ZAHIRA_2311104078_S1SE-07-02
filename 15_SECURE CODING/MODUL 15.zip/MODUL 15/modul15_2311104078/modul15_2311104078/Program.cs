﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

class Program
{
    static string filePath = "users.json";
    static List<User> users = new List<User>();

    static void Main()
    {
        LoadUsers();

        while (true)
        {
            Console.WriteLine("\n=== MENU ===");
            Console.WriteLine("1. Registrasi");
            Console.WriteLine("2. Login");
            Console.WriteLine("3. Keluar");
            Console.Write("Pilih menu: ");
            string input = Console.ReadLine();

            switch (input)
            {
                case "1": Register(); break;
                case "2": Login(); break;
                case "3": return;
                default: Console.WriteLine("Pilihan tidak valid."); break;
            }
        }
    }

    static void Register()
    {
        Console.Write("Masukkan username: ");
        string username = Console.ReadLine();

        Console.Write("Masukkan password: ");
        string password = Console.ReadLine();

        if (!ValidateUsername(username) || !ValidatePassword(password, username))
        {
            Console.WriteLine("Registrasi gagal: input tidak valid.");
            return;
        }

        if (users.Exists(u => u.Username == username))
        {
            Console.WriteLine("Username sudah terdaftar.");
            return;
        }

        string hash = HashPassword(password);
        users.Add(new User { Username = username, PasswordHash = hash });
        SaveUsers();

        Console.WriteLine("Registrasi berhasil!");
    }

    static void Login()
    {
        Console.Write("Masukkan username: ");
        string username = Console.ReadLine();

        Console.Write("Masukkan password: ");
        string password = Console.ReadLine();

        string hash = HashPassword(password);
        var user = users.Find(u => u.Username == username && u.PasswordHash == hash);

        if (user != null)
            Console.WriteLine($"Selamat datang, {username}!");
        else
            Console.WriteLine("Login gagal: username atau password salah.");
    }

    static bool ValidateUsername(string username)
    {
        if (string.IsNullOrWhiteSpace(username) || username.Length < 4 || username.Length > 20)
            return false;

        return Regex.IsMatch(username, @"^[a-zA-Z]+$");
    }

    static bool ValidatePassword(string password, string username)
    {
        if (string.IsNullOrWhiteSpace(password) || password.Length < 8 || password.Length > 20)
            return false;

        if (password.ToLower().Contains(username.ToLower()))
            return false;

        bool hasDigit = Regex.IsMatch(password, @"\d");
        bool hasSpecial = Regex.IsMatch(password, @"[!@#$%^&*]");

        return hasDigit && hasSpecial;
    }

    static string HashPassword(string password)
    {
        using SHA256 sha = SHA256.Create();
        byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
        return Convert.ToBase64String(hash);
    }

    static void SaveUsers()
    {
        string json = JsonSerializer.Serialize(users, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(filePath, json);
    }

    static void LoadUsers()
    {
        if (File.Exists(filePath))
        {
            string json = File.ReadAllText(filePath);
            users = JsonSerializer.Deserialize<List<User>>(json);
        }
    }
}
