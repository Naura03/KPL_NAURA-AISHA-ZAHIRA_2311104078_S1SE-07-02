﻿class Program
{
    static void Main(string[] args)
    {
        // Mendapatkan instance singleton
        var data1 = PusatDataSingleton.GetDataSingleton();
        var data2 = PusatDataSingleton.GetDataSingleton();

        // Tambahkan nama anggota kelompok dan asisten
        data1.AddSebuahData("Ahmad Al – Farizi");
        data1.AddSebuahData("Kafka Putra Riyadi");
        data1.AddSebuahData("Faishal Arif Setiawan");
        data1.AddSebuahData("Ganes Gemi Putra");
        data1.AddSebuahData("Naura Aisha Zahira");
        data1.AddSebuahData("Asisten: Devrin Anggun");

        // Cetak semua data menggunakan data2
        Console.WriteLine("Data dari data2:");
        data2.PrintSemuaData();

        // Hapus nama asisten dari data2
        data2.HapusSebuahData(5); // index ke-5 adalah "Asisten: Devrin Anggun"

        // Cek ulang isi data1 setelah penghapusan
        Console.WriteLine("\nSetelah penghapusan di data1:");
        data1.PrintSemuaData();

        // Cetak jumlah elemen pada masing-masing instance
        Console.WriteLine($"\nJumlah data pada data1: {data1.GetSemuaData().Count}");
        Console.WriteLine($"Jumlah data pada data2: {data2.GetSemuaData().Count}");
    }
}
