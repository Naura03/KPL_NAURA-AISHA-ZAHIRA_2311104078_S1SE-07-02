﻿using System;
using System.Collections.Generic;

// Observer Interface
public interface IObserver
{
    void Update(string message);
}

// Subject Interface
public interface ISubject
{
    void Attach(IObserver observer);
    void Detach(IObserver observer);
    void Notify(string message);
}

// Concrete Subject
public class NewsPublisher : ISubject
{
    private List<IObserver> observers = new List<IObserver>();

    public void Attach(IObserver observer)
    {
        observers.Add(observer);
    }

    public void Detach(IObserver observer)
    {
        observers.Remove(observer);
    }

    public void Notify(string message)
    {
        foreach (var observer in observers)
        {
            observer.Update(message);
        }
    }
}

// Concrete Observer
public class User : IObserver
{
    private string name;

    public User(string name)
    {
        this.name = name;
    }

    public void Update(string message)
    {
        Console.WriteLine($"{name} menerima notifikasi: {message}");
    }
}

// Program utama
class Program
{
    static void Main()
    {
        var publisher = new NewsPublisher();

        var user1 = new User("Naura");
        var user2 = new User("Aisha");

        publisher.Attach(user1);
        publisher.Attach(user2);

        publisher.Notify("Berita baru: Modul Observer Design Pattern dirilis!");

        publisher.Detach(user1);

        publisher.Notify("Update kedua: Contoh kode sudah lengkap!");
    }
}
