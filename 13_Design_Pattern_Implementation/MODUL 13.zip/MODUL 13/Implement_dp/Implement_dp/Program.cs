﻿using static singleton_dp.Singleton;
using adapter_dp;
using System.Security.Cryptography.X509Certificates;
using command_dp;
using command_dp;
using System.Numerics;
namespace design_pattern
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("==========Singleton==========");
            Rektor rektor1 = Rektor.GetRektor();
            Rektor rektor2 = Rektor.GetRektor();

            if (rektor1 != rektor2)
            {
                Console.WriteLine("Rektor sama");
            }
            else
            {
                Console.WriteLine("Rektor berbeda");
            }

            rektor1.Tandatangan();


            Console.WriteLine("");
            Console.WriteLine("===========Adapter=============");

            IndonesianPlug indonesianPlug = new IndonesianPlug();
            IAmericanPlug adaptor = new PlugAdapter(indonesianPlug);
            adaptor.PlugIn();

            Console.WriteLine("");
            Console.WriteLine("===========Command============");

            RemoteTV remote = new RemoteTV();
            Television tv = new Television();

            TelevisionTurnOn turnOn = new TelevisionTurnOn(tv);
            TelevisionTurnOff turnOff = new TelevisionTurnOff(tv);

            remote.setTurnOn(turnOn);
            remote.setTurnOff(turnOff);
            remote.TurnOnTV();
            remote.TurnOffTV();
        }
    }
}