﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adapter_dp
{
    public interface IAmericanPlug
    {
        void PlugIn();
    }

    public class IndonesianPlug
    {
        public void Sambungkan()
        {
            Console.WriteLine("Colokan Indonesia Tersambung");
        }
    }

    public class PlugAdapter : IAmericanPlug
    {
        private readonly IndonesianPlug _plug;
        public PlugAdapter(IndonesianPlug indonesianPlug)
        {
            _plug = indonesianPlug;
        }

        public void PlugIn()
        {
            Console.WriteLine("Menggunakan Adapter Colokan Indonesia ke Amerika");
            _plug.Sambungkan();
        }
    }
}